import { Request, Response } from 'express';
import Task from '../models/Task';

export const createTask = async (req: Request, res: Response) => {
    const task = await Task.create({ ...req.body, userId: req.user.id });
    res.status(201).json(task);
};

export const getTasks = async (req: Request, res: Response) => {
    const tasks = await Task.find({ userId: req.user.id });
    res.json(tasks);
};

export const updateTask = async (req: Request, res: Response) => {
    const task = await Task.findOneAndUpdate({ _id: req.params.id, userId: req.user.id }, req.body, { new: true });
    res.json(task);
};

export const deleteTask = async (req: Request, res: Response) => {
    await Task.findOneAndDelete({ _id: req.params.id, userId: req.user.id });
    res.status(204).send();
};